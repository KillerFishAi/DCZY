import json
import random
from typing import Dict, List


class AccountPool:
 """账号池：负责加载配置与轮询分配账号"""

 def __init__(self, config_path: str):
     self.config = self._load(config_path)
     self.accounts: List[Dict] = self.config["accounts"]
     if not self.accounts:
         raise ValueError("账号池为空，请检查 config.json")
         self._index = 0

 @staticmethod
 def _load(path: str) -> Dict:
     try:
         with open(path, "r", encoding="utf-8") as f:
             return json.load(f)
 except FileNotFoundError:
     raise FileNotFoundError(f"配置文件不存在: {path}")
 except json.JSONDecodeError as e:
     raise ValueError(f"配置文件 JSON 格式错误: {e}")

 def get_next_account(self) -> Dict:
     account = self.accounts[self._index]
     self._index = (self._index + 1) % len(self.accounts)
     return account

 def get_random_account(self) -> Dict:
     return random.choice(self.accounts)

 def get_accounts_by_city(self, city: str) -> List[Dict]:
     return [a for a in self.accounts if a.get("proxy_city") == city]

 def size(self) -> int:
     return len(self.accounts)