"""
验证码抓包探针
==============
自动触发东方财富评论验证码，逐个尝试候选接口与坐标编码，
定位真实的「获取图片」与「提交坐标」接口及 Payload 格式。

用法:
 python captcha_probe.py [config.json]

流程:
 1. 解析 postid
 2. 发评论触发验证码，拿到 context_id
 3. 遍历候选 GET 接口，找到能返回图片的那个
 4. 弹窗让你按指令点击（复用 ManualClickSolver）
 5. 遍历候选 POST 接口 × 坐标编码 × 参数名，找到能通过的那个
 6. 打印命中的组合，直接填进 config.json
"""
import asyncio
import base64
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

import aiohttp

from account_pool import AccountPool
from proxy_pool import ProxyPool
from eastmoney_api import EastMoneyAPI, encode_points
from captcha_solver import ManualClickSolver

Point = Tuple[int, int]

GET_CANDIDATES = [
 "/newsreply/replyopt/api/Validate/GetValidateCode",
 "/newsreply/replyopt/api/Validate/GetCode",
 "/newsreply/replyopt/api/Validate/GetValidateImage",
 "/newsreply/replyopt/api/Validate/GetImage",
 "/newsreply/replyopt/api/Validate/Image",
]

SUBMIT_CANDIDATES = [
 "/newsreply/replyopt/api/Validate/CheckValidateCode",
 "/newsreply/replyopt/api/Validate/CheckCode",
 "/newsreply/replyopt/api/Validate/ValidateCode",
 "/newsreply/replyopt/api/Validate/Check",
 "/newsreply/replyopt/api/Validate/Verify",
]

COORD_STYLES = ["pipe", "semicolon", "comma", "flat", "json", "jsonobj"]
PARAM_NAMES = ["validate", "code", "points", "coordinate", "answer", "result"]


class CaptchaProbe:
 def __init__(self, config_path: str):
     self.pool = AccountPool(config_path)
     self.proxy_pool = ProxyPool(config_path)
     self.task: Dict[str, Any] = self.pool.config["task"]
     self.account: Dict[str, Any] = self.pool.get_next_account()
     self.proxy: Optional[str] = self.proxy_pool.get_proxy_for_account(self.account)
     self.api: Optional[EastMoneyAPI] = None
     self.postid: Optional[str] = None
     self.context_id: Optional[str] = None
     self.image_bytes: Optional[bytes] = None
     self.prompt: str = ""
     self.hit_get: Optional[str] = None
     self.hit_submit: Optional[Tuple[str, str, str]] = None
     self.submit_response: Optional[Dict[str, Any]] = None

 async def run(self) -> None:
     connector = aiohttp.TCPConnector(ssl=False)
     timeout = aiohttp.ClientTimeout(total=30)
     async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
     self.api = EastMoneyAPI(session)
     await self._trigger_captcha()
     if not self.context_id:
         print("\n[!] 未拿到 context_id，无法继续。")
         return
         await self._find_get_endpoint()
         if not self.image_bytes:
             print("\n[!] 未取到验证码图片，无法继续。")
             return
             points = await self._collect_points()
             if not points:
                 print("\n[!] 未采集到坐标。")
                 return
                 await self._find_submit_endpoint(points)
                 await self._verify()
                 self._report()

 async def _trigger_captcha(self) -> None:
     print("=" * 60)
     print("[1] 解析 postid...")
     self.postid = await self.api.resolve_postid(
     self.task["url"], self.account, self.proxy
     )
     print(f" postid = {self.postid}")

 print("[2] 发评论触发验证码...")
 text = (self.task.get("comments") or ["探针测试评论"])[0]
 result = await self.api.comment(self.postid, text, self.account, self.proxy)
 print(f" status = {result.status.value}")
 print(f" message = {result.message}")
 if result.ok:
     print(" [!] 评论直接成功，未触发验证码。换个账号或再跑一次。")
     return
     if not result.needs_captcha:
         print(" [!] 非验证码失败，检查 Cookie / 代理。")
         return
         self.context_id = result.context_id
         print(f" context_id = {self.context_id}")
         print(f" 原始响应 = {json.dumps(result.raw, ensure_ascii=False)}")

 async def _find_get_endpoint(self) -> None:
     print("[3] 遍历候选接口获取验证码图片...")
     for path in GET_CANDIDATES:
         url = f"{self.api.BASE_CAIFUHAO}{path}"
         params = {"contextId": self.context_id, "_": str(int(time.time() * 1000))}
         headers = self.api._headers(self.account, referer=f"{self.api.BASE_CAIFUHAO}/")
         try:
             async with self.api.session.get(
             url, params=params, headers=headers, proxy=self.proxy
             ) as resp:
             ct = resp.headers.get("Content-Type", "")
             body = await resp.read()
             print(f" {path}")
             print(f" HTTP {resp.status} | Content-Type={ct} | {len(body)} bytes")
             if resp.status != 200 or not body:
                 continue
                 if "image" in ct:
                     self.image_bytes = body
                     self.prompt = ""
                     self.hit_get = path
                     self._save_image()
                     return
                     try:
                         j = json.loads(body)
 except Exception:
     print(f" 非 JSON，前 200 字节: {body[:200]!r}")
     continue
     print(f" JSON keys: {list(j.keys())}")
     img = self._dig_image(j)
     if img:
         self.image_bytes = img
         self.prompt = self._dig_prompt(j)
         self.hit_get = path
         self._save_image()
         return
 except Exception as e:
     print(f" {path} 异常: {e}")

 @staticmethod
 def _dig_image(j: Dict[str, Any]) -> Optional[bytes]:
     for key in ("image", "img", "data", "pic", "base64"):
         v = j.get(key)
         if isinstance(v, dict):
             for k2 in ("image", "img", "data", "pic", "base64"):
                 v = v.get(k2)
                 if isinstance(v, str) and v:
                     break
                     if isinstance(v, str) and v:
                         if v.startswith("data:"):
                             v = v.split(",", 1)[1]
                             try:
                                 return base64.b64decode(v)
 except Exception:
     continue
     return None

 @staticmethod
 def _dig_prompt(j: Dict[str, Any]) -> str:
     for key in ("text", "prompt", "tip", "word", "words", "title", "me"):
         v = j.get(key)
         if isinstance(v, str) and v:
             return v
             return ""

 def _save_image(self) -> None:
     os.makedirs("captcha", exist_ok=True)
     path = os.path.join("captcha", f"probe_{int(time.time())}.png")
     with open(path, "wb") as f:
         f.write(self.image_bytes)
         print(f" >>> 命中！图片已保存: {path}")
         print(f" >>> 指令文字: {self.prompt!r}")

 async def _collect_points(self) -> List[Point]:
     print("[4] 请按指令顺序点击图片...")
     solver = ManualClickSolver(save_dir="captcha")
     points = await solver.solve(self.image_bytes, self.prompt)
     print(f" 采集到坐标: {points}")
     return points or []

 async def _find_submit_endpoint(self, points: List[Point]) -> None:
     print("[5] 遍历候选接口 × 编码 × 参数名 提交坐标...")
     for path in SUBMIT_CANDIDATES:
         for style in COORD_STYLES:
             for pname in PARAM_NAMES:
                 url = f"{self.api.BASE_CAIFUHAO}{path}"
                 data = {
                 "contextId": self.context_id,
                 pname: encode_points(points, style),
                 "plat": "Web",
                 "version": "100",
                 "product": "EastMoney",
                 "deviceid": self.account["deviceid"],
                 }
                 headers = self.api._headers(
                 self.account, referer=f"{self.api.BASE_CAIFUHAO}/"
                 )
                 headers["Content-Type"] = (
                 "application/x-www-form-urlencoded; charset=UTF-8"
                 )
                 try:
                     async with self.api.session.post(
                     url, data=data, headers=headers, proxy=self.proxy
                     ) as resp:
                     body = await resp.text()
                     print(f" {path} | {pname}={style}")
                     print(f" HTTP {resp.status} | {body[:200]}")
                     if self._looks_success(body):
                         self.hit_submit = (path, pname, style)
                         try:
                             self.submit_response = json.loads(body)
 except Exception:
     self.submit_response = {}
     print(" >>> 命中！")
     return
 except Exception as e:
     print(f" {path} | {pname}={style} 异常: {e}")

 @staticmethod
 def _looks_success(body: str) -> bool:
     try:
         j = json.loads(body)
 except Exception:
     return False
     if j.get("rc") == 1:
         return True
         if j.get("validate") or j.get("token"):
             return True
             return False

 async def _verify(self) -> None:
     if not self.hit_submit or not self.submit_response:
         return
         token = (
         self.submit_response.get("validate")
         or self.submit_response.get("token")
         or ""
         )
         if not token:
             print("[6] 提交响应里没有 validate/token 字段，跳过端到端验证。")
             return
             print("[6] 用拿到的 token 重发评论做端到端验证...")
             text = (self.task.get("comments") or ["探针测试评论"])[0]
             retry = await self.api.comment(
             self.postid, text, self.account, self.proxy,
             validate=token, context_id=self.context_id,
             )
             print(f" status = {retry.status.value}")
             print(f" message = {retry.message}")
             if retry.ok:
                 print(" >>> 端到端验证通过，链路完全打通！")
 else:
     print(" [!] 端到端未通过，token 字段名可能不同，看上面原始响应。")

 def _report(self) -> None:
     print("=" * 60)
     print("探针结果")
     print("=" * 60)
     print(f"GET 接口: {self.hit_get}")
     if self.hit_submit:
         path, pname, style = self.hit_submit
         print(f"POST 接口: {path}")
         print(f"参数名: {pname}")
         print(f"坐标编码: {style}")
         print("\n把以下内容填入 config.json 的 settings：")
         print(json.dumps({
         "captcha_path": self.hit_get,
         "captcha_submit_path": path,
         "captcha_coord_param": pname,
         "captcha_coord_format": style,
         }, ensure_ascii=False, indent=2))
 else:
     print("POST 接口: 未命中，请把上面的原始响应发出来人工判断")


def main() -> None:
 config_path = sys.argv[1] if len(sys.argv) > 1 else "config.json"
 probe = CaptchaProbe(config_path)
 try:
     asyncio.run(probe.run())
 except KeyboardInterrupt:
     print("\n[中断]")


if __name__ == "__main__":
 main()