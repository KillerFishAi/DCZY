import asyncio
import io
import os
from abc import ABC, abstractmethod
from typing import List, Optional, Tuple

Point = Tuple[int, int]


class BaseClickCaptchaSolver(ABC):
 """点选验证码求解器基类"""

 @abstractmethod
 async def solve(self, image_bytes: bytes, prompt: str) -> Optional[List[Point]]:
     raise NotImplementedError


class DdddOcrClickSolver(BaseClickCaptchaSolver):
 """自动求解：ddddocr 检测字框 + 识别 + 按指令排序"""

 def __init__(self):
     try:
         import ddddocr
         from PIL import Image
 except ImportError as e:
     raise ImportError(f"缺少依赖: {e}，请执行 pip install ddddocr pillow")
     self._Image = Image
     self.det = ddddocr.DdddOcr(det=True, show_ad=False)
     self.ocr = ddddocr.DdddOcr(show_ad=False)

 async def solve(self, image_bytes: bytes, prompt: str) -> Optional[List[Point]]:
     prompt = (prompt or "").replace("请依次点击：", "").replace("请依次点击:", "").strip()
     if not prompt:
         return None

 try:
     boxes = await asyncio.to_thread(self.det.detection, image_bytes)
     if not boxes:
         return None

 img = self._Image.open(io.BytesIO(image_bytes))
 char_map: List[Tuple[str, Point]] = []
 for x1, y1, x2, y2 in boxes:
     x1, y1 = max(0, int(x1)), max(0, int(y1))
     x2, y2 = int(x2), int(y2)
     if x2 <= x1 or y2 <= y1:
         continue
         crop = img.crop((x1, y1, x2, y2))
         buf = io.BytesIO()
         crop.save(buf, format="PNG")
         char = await asyncio.to_thread(
         self.ocr.classification, buf.getvalue()
         )
         char = (char or "").strip()
         if char:
             center = ((x1 + x2) // 2, (y1 + y2) // 2)
             char_map.append((char, center))

 if not char_map:
     return None

 points: List[Point] = []
 used = set()
 for target in prompt:
     found = None
     for idx, (char, center) in enumerate(char_map):
         if idx in used:
             continue
             if target in char or char in target:
                 found = (idx, center)
                 break
                 if found is None:
                     continue
                     used.add(found[0])
                     points.append(found[1])

 return points or None

 except Exception as e: # noqa: BLE001
     print(f"[点选求解] 识别异常: {e}")
     return None


class ManualClickSolver(BaseClickCaptchaSolver):
 """手动求解：弹窗显示图片，鼠标按指令顺序点击"""

 def __init__(self, save_dir: str = "captcha"):
     self.save_dir = save_dir
     os.makedirs(save_dir, exist_ok=True)
     self._counter = 0

 async def solve(self, image_bytes: bytes, prompt: str) -> Optional[List[Point]]:
     self._counter += 1
     path = os.path.join(self.save_dir, f"captcha_{self._counter}.png")
     with open(path, "wb") as f:
         f.write(image_bytes)
         print(f"[点选求解] 图片已保存: {path}")
         points = await asyncio.to_thread(self._run_tk, path, prompt)
         return points if points else None

 def _run_tk(self, path: str, prompt: str) -> List[Point]:
     import tkinter as tk
     from PIL import Image, ImageTk

 clicked: List[Point] = []
 root = tk.Tk()
 root.title(f"按顺序点击: {prompt}")

 img = Image.open(path)
 tk_img = ImageTk.PhotoImage(img)

 canvas = tk.Canvas(root, width=img.width, height=img.height + 30)
 canvas.pack()
 canvas.create_image(0, 30, anchor=tk.NW, image=tk_img)
 canvas.create_text(
 img.width // 2, 15,
 text=f"请依次点击: {prompt}",
 fill="red", font=("Arial", 14, "bold"),
 )

 def on_click(event):
     if event.y > 30:
         pt = (event.x, event.y - 30)
         clicked.append(pt)
         canvas.create_oval(
         event.x - 5, event.y - 5, event.x + 5, event.y + 5,
         outline="red", width=2,
         )
         canvas.create_text(
         event.x, event.y - 12,
         text=str(len(clicked)), fill="red",
         )

 def on_close():
     root.destroy()

 canvas.bind("<Button-1>", on_click)
 root.protocol("WM_DELETE_WINDOW", on_close)
 root.mainloop()
 return clicked


def build_solver(mode: str) -> Optional[BaseClickCaptchaSolver]:
 mode = (mode or "manual").lower()
 if mode == "off":
     return None
     if mode == "ocr":
         return DdddOcrClickSolver()
         return ManualClickSolver()