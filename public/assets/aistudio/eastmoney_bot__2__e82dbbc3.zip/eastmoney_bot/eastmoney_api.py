import re
import json
import time
from enum import Enum
from typing import Any, Dict, List, Optional

import aiohttp


class CommentStatus(Enum):
 SUCCESS = "success"
 CAPTCHA_REQUIRED = "captcha_required"
 FAILED = "failed"


class CommentResult:
 """评论结果的结构化封装"""

 __slots__ = ("status", "message", "reply_id", "context_id", "raw")

 def __init__(
 self,
 status: CommentStatus,
 message: str,
 reply_id: Optional[int] = None,
 context_id: Optional[str] = None,
 raw: Optional[Dict[str, Any]] = None,
 ):
 self.status = status
 self.message = message
 self.reply_id = reply_id
 self.context_id = context_id
 self.raw = raw or {}

 @property
 def ok(self) -> bool:
     return self.status is CommentStatus.SUCCESS

 @property
 def needs_captcha(self) -> bool:
     return self.status is CommentStatus.CAPTCHA_REQUIRED

 def __repr__(self) -> str:
     return f"<CommentResult {self.status.value} {self.message!r}>"


class EastMoneyAPI:
 """东方财富财富号接口封装（异步）"""

 BASE_CAIFUHAO = "https://caifuhao.eastmoney.com"
 BASE_GBAPI = "https://gbapi.eastmoney.com"

 UA = (
 "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
 "AppleWebKit/537.36 (KHTML, like Gecko) "
 "Chrome/120.0.0.0 Safari/537.36"
 )

 def __init__(self, session: aiohttp.ClientSession):
     self.session = session

 # ---------------- 内部工具 ----------------

 def _headers(
 self, account: Dict[str, Any], referer: Optional[str] = None
 ) -> Dict[str, str]:
 headers = {
 "Accept": "*/*",
 "Accept-Language": "zh-CN,zh;q=0.9",
 "User-Agent": self.UA,
 "Cookie": account["cookie"],
 }
 if referer:
     headers["Referer"] = referer
     return headers

 @staticmethod
 def _parse_jsonp(text: str) -> Dict[str, Any]:
     m = re.search(r"^[^(]*\((.*)\)\s*;?\s*$", text.strip(), re.S)
     if not m:
         raise ValueError(f"非 JSONP 格式: {text[:120]}")
         return json.loads(m.group(1))

 @staticmethod
 def extract_article_id(url: str) -> str:
     m = re.search(r"/news/(\d+)", url)
     if not m:
         raise ValueError(f"无法从 URL 提取文章编号: {url}")
         return m.group(1)

 @staticmethod
 def extract_url_id(html_content: str) -> str:
     """从 HTML 中提取 URL 编号（用于点赞）"""
     # 文档说用正则提取，这里假设一种常见的文章 ID 格式
     # 实际需根据文章页 HTML 结构调整
     m = re.search(r'window\.articleId\s*=\s*"(\d+)"', html_content)
     if not m:
         raise ValueError(f"无法从 HTML 提取 URL 编号")
         return m.group(1)

 # ---------------- 1. 详情：URL编号 -> postid ----------------

 async def resolve_postid(
 self,
 article_url: str,
 account: Dict[str, Any],
 proxy: Optional[str],
 ) -> str:
 headers = self._headers(account, referer=article_url)
 params = {}
 proxies = {"http": proxy, "https": proxy} if proxy else None

 async with self.session.get(article_url, headers=headers, params=params, proxy=proxy) as resp:
 html = await resp.text()
 return self.extract_url_id(html)

 # ---------------- 2. 查询状态 ----------------

 async def get_like_status(
 self,
 postid: str,
 account: Dict[str, Any],
 proxy: Optional[str],
 ) -> Dict[str, Any]:
 """返回是否已点赞的信息"""
 url = f"{self.BASE_CAIFUHAO}/v1/ArticleAndReplyLikeInfo?postid={postid}"
 headers = self._headers(account)
 proxies = {"http": proxy, "https": proxy} if proxy else None

 async with self.session.get(url, headers=headers, proxy=proxy) as resp:
 data = await resp.json()
 return data

 # ---------------- 3. 点赞 ----------------

 async def like_article(
 self,
 url_id: str,
 account: Dict[str, Any],
 proxy: Optional[str],
 ) -> bool:
 """点赞接口"""
 url = f"{self.BASE_GBAPI}//likeopt/JSONP/LikeArticle"
 params = {
 "version": "100",
 "product": "EastMoney",
 "plat": "Web",
 "h": account["h"],
 "deviceid": account["like_deviceid"],
 "callback": "cb855",
 "type": "20",
 "id": url_id,
 "_": str(int(time.time() * 1000)),
 }
 headers = self._headers(account, referer=f"{self.BASE_CAIFUHAO}/news/{url_id}")
 proxies = {"http": proxy, "https": proxy} if proxy else None

 async with self.session.get(url, headers=headers, params=params, proxy=proxy) as resp:
 text = await resp.text()
 # 点赞通常返回 JSONP 或包含 rc:1 的文本
 try:
     return self._parse_jsonp(text).get("rc") == 1
 except:
     return "rc:1" in text

 # ---------------- 4. 评论（跳过验证码逻辑） ----------------

 async def comment_article(
 self,
 postid: str,
 text: str,
 account: Dict[str, Any],
 proxy: Optional[str],
 ) -> CommentResult:
 """执行评论。如果需要验证码 rc:2，直接返回失败状态，不尝试自动解决"""
 url = f"{self.BASE_CAIFUHAO}/newsreply/replyopt/api/Reply/WebReplyArticle"
 headers = {
 "Accept": "application/json, text/javascript, */*; q=0.01",
 "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
 "User-Agent": self.UA,
 "Cookie": account["cookie"],
 "Referer": f"{self.BASE_CAIFUHAO}/news/{postid}",
 }
 proxies = {"http": proxy, "https": proxy} if proxy else None

 data = {
 "id": postid,
 "text": text,
 "pic": "",
 "t_type": "0",
 "account": "",
 "validate": "",
 "contextId": "",
 "plat": "Web",
 "version": "100",
 "product": "EastMoney",
 "deviceid": account["deviceid"],
 "path": "replyopt/api/Reply/WebReplyArticle",
 }

 async with self.session.post(url, headers=headers, data=data, proxy=proxy) as resp:
 result = await resp.json()
 # 文档指出：rc:1 成功，rc:2 + error_code:108 需验证码
 rc = result.get("rc")

 if rc == 1:
     return CommentResult(
     status=CommentStatus.SUCCESS,
     message="评论成功",
     reply_id=result.get("reply_id"),
     raw=result,
     )
 elif rc == 2:
     # 如果是 2，说明需要验证码，我们直接返回 CAPTCHA_REQUIRED
     # 在 MainEngine 中会捕获此状态并切换账号
     return CommentResult(
     status=CommentStatus.CAPTCHA_REQUIRED,
     message="需要验证码，切换账号",
     context_id=result.get("context_id"),
     raw=result,
     )
 else:
     return CommentResult(
     status=CommentStatus.FAILED,
     message=f"评论失败: rc={rc}, msg={result}",
     raw=result,
     )

 # ---------------- 5. 点击（提升阅读量） ----------------

 async def click_article(
 self,
 article_url: str,
 account: Dict[str, Any],
 proxy: Optional[str],
 ) -> bool:
 """打开文章页面，模拟点击"""
 headers = self._headers(account, referer=article_url)
 proxies = {"http": proxy, "https": proxy} if proxy else None

 try:
     async with self.session.get(article_url, headers=headers, proxy=proxy, allow_redirects=True) as resp:
     return resp.status == 200
 except Exception as e:
     print(f"点击失败: {e}")
     return False