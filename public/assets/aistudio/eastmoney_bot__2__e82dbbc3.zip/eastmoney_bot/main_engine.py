import asyncio
import random
import json
import time
from typing import Dict, List

from account_pool import AccountPool
from proxy_pool import Proxy池
from eastmoney_api import EastMoneyAPI, CommentStatus
from captcha_solver import ClickCaptchaSolver


class MainEngine:
 def __init__(self, config_path: str):
     self.config_path = config_path
     self.pool = AccountPool(config_path)
     self.proxy_pool = ProxyPool(config_path)
     self.api = None
     self.solver = ClickCaptchaSolver()
     self.stats = {
     "clicks": 0,
     "likes": 0,
     "comments": 0,
     "captcha_tries": 0,
     "failed_accounts": 0
     }

 async def run(self):
     print("引擎启动...")
 
 # 获取任务配置
 if not hasattr(self, 'config'):
     with open(self.config_path, 'r', encoding='utf-8') as f:
         self.config = json.load(f)

 # 简单的模拟并发控制
 async def worker(account):
     account_data = account
     proxy_url = self.proxy_pool.get_proxy_for_account(account_data)
     proxy_str = f"http://{account_data['proxy_ip']}:{account_data['proxy_port']}" if proxy_url else None
 
 # 创建会话
 connector = aiohttp.TCPConnector(limit=10)
 async with aiohttp.ClientSession(connector=connector) as session:
 api_instance = EastMoneyAPI(session)
 
 try:
     # 1. 解析 PostID
     article_url = self.config["task"]["url"]
     postid = await api_instance.resolve_postid(article_url, account_data, proxy_str)
     print(f"[{account_data['username']}] 文章解析完成: postid={postid}")

 # 2. 查询状态并点赞
 like_status = await api_instance.get_like_status(postid, account_data, proxy_str)
 if like_status.get("isLike") == 0:
     url_id = await api_instance.resolve_postid(article_url, account_data, proxy_str)
     success = await api_instance.like_article(url_id, account_data, proxy_str)
     if success:
         self.stats["likes"] += 1
         print(f"[{account_data['username']}] 点赞成功")

 # 3. 发评论
 comments = self.config["task"]["comments"]
 comment_text = random.choice(comments)
 result = await api_instance.comment_article(
 postid, comment_text, account_data, proxy_str, self.solver
 )
 
 if result.ok:
     self.stats["comments"] += 1
     print(f"[{account_data['username']}] 评论成功: {comment_text}")
 elif result.needs_captcha:
     self.stats["captcha_tries"] += 1
     self.stats["failed_accounts"] += 1
     print(f"[{account_data['username']}] ⚠️ 需要验证码，跳过该账号")
 else:
     self.stats["failed_accounts"] += 1
     print(f"[{account_data['username']}] 评论失败: {result.message}")

 # 4. 点击量提升 (简单的 GET 请求)
 await api_instance.click_article(article_url, account_data, proxy_str)
 self.stats["clicks"] += 1

 except Exception as e:
     print(f"[{account_data['username']}] 运行出错: {e}")
     self.stats["failed_accounts"] += 1

 # 创建任务队列
 tasks = []
 for _ in range(self.config["settings"]["max_concurrency"]):
     acc = self.pool.get_next_account()
     if acc:
         tasks.append(worker(acc))
 else:
     print("账号池已空，停止任务")
     break

 if tasks:
     await asyncio.gather(*tasks)
     self.print_summary()

 def print_summary(self):
     print("\n" + "="*30)
     print("=== 执行摘要 ===")
     print(f"点击量提升: {self.stats['clicks']}")
     print(f"点赞数: {self.stats['likes']}")
     print(f"评论成功数: {self.stats['comments']}")
     print(f"验证码跳过数: {self.stats['captcha_tries']}")
     print(f"其他失败数: {self.stats['failed_accounts']}")
     print("="*30)


async def main():
 engine = MainEngine("config.json")
 await engine.run()


if __name__ == "__main__":
 import aiohttp
 asyncio.run(main())