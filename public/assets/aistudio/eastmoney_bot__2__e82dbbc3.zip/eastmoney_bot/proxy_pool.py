import json
from typing import Dict, Optional


class ProxyPool:
 """代理池：为每个账号构建对应的代理 URL"""

 def __init__(self, config_path: str):
     with open(config_path, "r", encoding="utf-8") as f:
         self.config = json.load(f)

 def get_proxy_for_account(self, account: Dict) -> Optional[str]:
     ip = account.get("proxy_ip")
     if not ip:
         return None
         port = account.get("proxy_port", 1080)
         user = account.get("proxy_user")
         password = account.get("proxy_pass")
         if user and password:
             return f"http://{user}:{password}@{ip}:{port}"
             return f"http://{ip}:{port}"

 def get_city_of_account(self, account: Dict) -> str:
     return account.get("proxy_city", "Unknown")